const Footer = () => {
  return (
    <footer className="footer">
      <div>Ibra@utas.edu.om|©2024|PostIT|All Rights Reserved.</div>
    </footer>
  );
};

export default Footer;
