import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import bcrypt from "bcrypt";
import UserModel from "./Models/UserModel.js";
import PostModel from "./Models/PostModel.js";
const app = express();
app.use(express.json());
app.use(cors());

//Database connection
const connectString ="mongodb+srv://admin:admin@postitcluster.vifrg.mongodb.net/?retryWrites=true&w=majority&appName=PostITCluster";
mongoose.connect(connectString);

app.post("/registerUser", async (req, res) => {
  try {
    const name = req.body.name;
    const email = req.body.email;
    const password = req.body.password;
    const hashedpassword = await bcrypt.hash(password, 10);

    const user = new UserModel({
      name: name,
      email: email,
      password: hashedpassword,
    });

    await user.save();
    res.send({ user: user, msg: "Added." });
  } catch (error) {
    res.status(500).json({ error: "An error occurred" });
  }
});

app.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body; //using destructuring
    //search the user
    const user = await UserModel.findOne({ email: email });

    //if not found
    if (!user) {
      return res.status(500).json({ error: "User not found." });
    }
    console.log(user);
    const passwordMatch = await bcrypt.compare(password, user.password);

    if (!passwordMatch) { return res.status(401).json({ error: "Authentication failed" });
  }

  //if everything is ok, send the user and message
  res.status(200).json({ user, message: "Success." });
} catch (err) {
  res.status(500).json({ error: err.message });
}
});
app.post("/logout", async (req, res) => {
  res.status(200).json({ message: "Logged out successfully" });
 });
 
 app.post("/logout", async (req, res) => {
  res.status(200).json({ message: "Logged out successfully" });
});

app.post("/savePost",async(req,ers)=>{
try{
  const postMsg=req.body.postMsg;
  const email=req.body.email;
  const post=new PostModel({
    postMsg:postMsg,
    email:email,
  });
  await post.save();
  res.send({post: post,msg:"Added."});
} catch (error){
  res.status(500).json({error:"An error occurred"});
}
});
app.get("/getPosts", async (req, res) => {
  try {
    const posts = await PostModel.find({}).sort({ createdAt: -1 });
    const countPost = await PostModel.countDocuments({});
    res.send({ posts: posts, count: countPost });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "An error occurred" });
  }
});


app.listen(3001, () => {
  console.log("You are connected");
});
app.put("/updateUserProfile/: email/", async (req, res) => {
  //Retrieve the value from the route
  const name = req.body.name;
  const password = req.body.password;

  const email= req.params.email;

  try {
    // Search for the user that will be updated using the findOne method
    const userToUpdate = await UserModel.findOne({ email: email });

    // Check if the user was found
    if (!userToUpdate) {
      return res.status(404).json({ error: "User not found" });
    }
    // Update the user's name
    userToUpdate.name = name;

    //if the user changed the password, change the password in the Db to the new hashed password
    if (password !== userToUpdate.password) {
      const hashedpassword = await bcrypt.hash(password, 10);
      userToUpdate.password = hashedpassword;
    } else {
      //if the user did not change the password
      userToUpdate.password = password;
    }

    // Save the updated user
    await userToUpdate.save(); // Make sure to save the changes

    // Return the updated user as a response
    res.send({ user: userToUpdate, msg: "Updated." });


  } catch (err) {
    res.status(500).json({ error: err });
    return;
  }
  
});

